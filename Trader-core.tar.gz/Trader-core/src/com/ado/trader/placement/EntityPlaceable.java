package com.ado.trader.placement;

import com.ado.trader.entities.EntityCollection;
import com.ado.trader.entities.components.Area;
import com.ado.trader.entities.components.Position;
import com.ado.trader.gui.CreateNpcWindow;
import com.ado.trader.input.InputHandler;
import com.ado.trader.map.IntMapLayer;
import com.ado.trader.map.Map;
import com.ado.trader.rendering.EntityRenderSystem;
import com.ado.trader.utils.IsoUtils;
import com.artemis.ComponentMapper;
import com.artemis.Entity;
import com.artemis.annotations.Wire;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

@Wire
public class EntityPlaceable extends Placeable {
	public int entityTypeID, spriteId;
	Sprite sprite;
	InputHandler input;
	EntityCollection entities;
	ComponentMapper<Area> areaMapper;
	EntityRenderSystem entityRenderer;
	CreateNpcWindow createNpcWindow;
	
	public EntityPlaceable(Map map, InputHandler input, CreateNpcWindow createNpcWindow, EntityCollection entities, EntityRenderSystem entityRenderer) {
		super(map);
		this.input = input;
		this.entities = entities;
		this.entityRenderer = entityRenderer;
		this.createNpcWindow = createNpcWindow;
	}
	
	public void place(int x,int y){
		if(entityTypeID == 0 && createNpcWindow != null){
			createNpcWindow.showWindow((int)input.getIsoClicked().x, (int)input.getIsoClicked().y);
			return;
		}
		Sprite s = new Sprite(sprite);
		Entity e = entities.createEntity(entityTypeID,spriteId , s);
		e.getComponent(Position.class).setPosition(x, y, map.currentLayer);

		rotateArea(e);
		
		map.getEntityLayer().addToMap(e.getId(), x, y, map.currentLayer);
		markAreaOccupied(x, y, map.currentLayer, e, map.getEntityLayer());
		
		if(sprite.isFlipX()){
			sprite.flip(true, false);
		}
	}
	
	public void remove(int x, int y){
		if(map.getEntityLayer().isOccupied(x, y, map.currentLayer)){
			entities.deleteEntity(x,y, map.currentLayer, map.getEntityLayer());
		}
	}
	
	public void markAreaOccupied(int x, int y, int h, Entity e, IntMapLayer layer){
		if (!areaMapper.has(e)) return;
		
		Area a = areaMapper.get(e);
		for(Vector2 vec: a.area){
			layer.addToMap(e.getId(), (int)(x+vec.x), (int)(y+vec.y), h);
		}
	}
	private void rotateArea(Entity e){
		if (areaMapper.has(e)) {
			if (sprite.isFlipX()) {
				for (Vector2 vec : areaMapper.get(e).area) {
					vec.rotate90(1);
				}
			}
		}
	}
	public void renderPreview(SpriteBatch batch){
		if(delete || entityTypeID == 0)return;
		
		Vector2 mousePos = IsoUtils.getColRow((int)input.getMousePos().x, (int)input.getMousePos().y,
				map.getTileWidth(), map.getTileHeight());
		
		mousePos = IsoUtils.getIsoXY((int)mousePos.x, (int)mousePos.y, 
				map.getTileWidth(), map.getTileHeight());
		
		batch.begin();
		if(entities.getEntities().get(entityTypeID).containsKey("area")){
			if(sprite.isFlipX()){
				batch.draw(sprite , mousePos.x-4, mousePos.y-32, 
						sprite.getWidth()*sprite.getScaleX(), sprite.getHeight()*sprite.getScaleY());
			}else{
				batch.draw(sprite , mousePos.x-68, mousePos.y-32, 
						sprite.getWidth()*sprite.getScaleX(), sprite.getHeight()*sprite.getScaleY());
			}
			return;
		}
		
		batch.draw(sprite, mousePos.x, mousePos.y, 
				sprite.getWidth()*sprite.getScaleX(), sprite.getHeight()*sprite.getScaleY());
		batch.end();
	}
	
	public void rotateSelection(){
		String[] tmp = entities.getEntities().get(entityTypeID).get("sprite").split(",");
		if(tmp.length==1){
			sprite.flip(true, false);
			return;
		}
		if(sprite.isFlipX()){
			sprite.flip(true, false);
			for(String s:tmp){
				int i = Integer.valueOf(s);
				if(i==spriteId)continue;
				spriteId = i;
				sprite = entityRenderer.getStaticSprites().get(i);
				break;
			}
		}else{
			sprite.flip(true, false);
		}
	}
	
	public void dragPlace(Vector2 start, Vector2 widthHeight) {}
}
