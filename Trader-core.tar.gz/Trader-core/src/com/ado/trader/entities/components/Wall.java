package com.ado.trader.entities.components;

import com.ado.trader.rendering.EntityRenderSystem.Direction;
import com.artemis.Component;

public class Wall extends Component {
	public Direction firstSprite, secondSprite;

}
