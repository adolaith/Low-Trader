package com.ado.trader.entities.components;

import com.artemis.Component;
import com.badlogic.gdx.graphics.g2d.Sprite;

//Contains the entity's spriteid's 
public class SpriteComp extends Component {
	public Sprite mainSprite,secondarySprite;
	public int mainId, secondId;
	
	public SpriteComp() {
	}
}
