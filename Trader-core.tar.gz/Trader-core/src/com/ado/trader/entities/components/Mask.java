package com.ado.trader.entities.components;

import com.artemis.Component;
import com.badlogic.gdx.graphics.g2d.Sprite;

public class Mask extends Component {
	public Sprite mask;
}
