package com.ado.trader.entities.components;

import com.artemis.Component;

public class Money extends Component{
	public int value;

	public Money() {
	}
}
