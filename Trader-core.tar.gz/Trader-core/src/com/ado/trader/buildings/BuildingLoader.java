package com.ado.trader.buildings;

public class BuildingLoader {

	public BuildingLoader() {
		// TODO Auto-generated constructor stub
	}

}
