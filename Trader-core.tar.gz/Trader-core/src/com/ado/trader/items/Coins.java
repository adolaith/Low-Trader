package com.ado.trader.items;

public class Coins extends ItemData {

	public Coins(int value) {
		super("coins");
		this.value = value;
	}

}
