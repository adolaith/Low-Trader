package com.ado.trader.items;

public class ToolItem extends ItemData {
	
	public ToolItem(int value){
		super("Tool");
		this.value = value;
	}
}
