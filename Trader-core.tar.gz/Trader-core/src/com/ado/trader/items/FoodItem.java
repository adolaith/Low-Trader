package com.ado.trader.items;

public class FoodItem extends ItemData {
	
	public FoodItem(int value){
		super("Food");
		this.value = value;
	}
}
